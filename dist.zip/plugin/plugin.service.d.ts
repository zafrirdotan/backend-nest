export declare class PluginService {
}
