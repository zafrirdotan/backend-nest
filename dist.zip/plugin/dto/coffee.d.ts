interface coffee {
    id: number;
    name: string;
    price: number;
    currency: string;
    description: string;
    calories: number;
    temperature: string;
    deliveryTime: string;
}
