export declare class PluginModule {
}
