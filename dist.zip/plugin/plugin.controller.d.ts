import { PluginService } from './plugin.service';
export declare class PluginController {
    private pluginService;
    constructor(pluginService: PluginService);
    getCoffee(): {
        id: number;
        name: string;
        price: number;
        currency: string;
        description: string;
        calories: number;
        temperature: string;
        deliveryTime: string;
    }[];
    getCoffeeById(id: number): {
        id: number;
        name: string;
        price: number;
        currency: string;
        description: string;
        calories: number;
        temperature: string;
        deliveryTime: string;
    };
    getCoffeeByName(name: string): {
        id: number;
        name: string;
        price: number;
        currency: string;
        description: string;
        calories: number;
        temperature: string;
        deliveryTime: string;
    };
    getCoffeeByPrice(price: number): {
        id: number;
        name: string;
        price: number;
        currency: string;
        description: string;
        calories: number;
        temperature: string;
        deliveryTime: string;
    };
    getOas(): Promise<void>;
    getPlugin(): Promise<{
        schema_version: string;
        name_for_human: string;
        name_for_model: string;
        description_for_human: string;
        description_for_model: string;
        auth: {
            type: string;
        };
        api: {
            type: string;
            url: string;
        };
        logo_url: string;
        contact_email: string;
        legal_info_url: string;
    }>;
}
