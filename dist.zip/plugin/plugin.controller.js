"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PluginController = void 0;
const common_1 = require("@nestjs/common");
const coffees_1 = require("./data/coffees");
const plugin_service_1 = require("./plugin.service");
const oas = require("./oas.json");
const manifest = require("./ai-plugin.json");
let PluginController = exports.PluginController = class PluginController {
    constructor(pluginService) {
        this.pluginService = pluginService;
    }
    getCoffee() {
        return coffees_1.coffeeList;
    }
    getCoffeeById(id) {
        return coffees_1.coffeeList.find(coffee => coffee.id === 1);
    }
    getCoffeeByName(name) {
        return coffees_1.coffeeList.find(coffee => coffee.name === name);
    }
    getCoffeeByPrice(price) {
        return coffees_1.coffeeList.find(coffee => coffee.price === price);
    }
    async getOas() {
        return oas;
    }
    async getPlugin() {
        return manifest;
    }
};
__decorate([
    (0, common_1.Get)('coffee-list'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PluginController.prototype, "getCoffee", null);
__decorate([
    (0, common_1.Get)('coffee-list/:id'),
    __param(0, (0, common_1.Query)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], PluginController.prototype, "getCoffeeById", null);
__decorate([
    (0, common_1.Get)('coffee-list/:name'),
    __param(0, (0, common_1.Query)('name')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PluginController.prototype, "getCoffeeByName", null);
__decorate([
    (0, common_1.Get)('coffee-list/:price'),
    __param(0, (0, common_1.Query)('price')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], PluginController.prototype, "getCoffeeByPrice", null);
__decorate([
    (0, common_1.Get)('oas-file'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PluginController.prototype, "getOas", null);
__decorate([
    (0, common_1.Get)('/well-known/ai-plugin.json'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PluginController.prototype, "getPlugin", null);
exports.PluginController = PluginController = __decorate([
    (0, common_1.Controller)('plugin'),
    __metadata("design:paramtypes", [plugin_service_1.PluginService])
], PluginController);
//# sourceMappingURL=plugin.controller.js.map