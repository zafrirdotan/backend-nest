import { User } from './user.entity';
import { TempUser } from './temp-user.entity';
import { Model } from 'mongoose';
export declare class UsersService {
    private readonly userModel;
    readonly users: User[];
    readonly tempUsers: TempUser[];
    constructor(userModel: Model<User>);
    create(user: User): Promise<User>;
    findOneByEmail(email: string): Promise<User>;
    findAll(): Promise<User[]>;
}
