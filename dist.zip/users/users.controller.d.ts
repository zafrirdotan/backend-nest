import { UsersService } from './users.service';
import { User } from './user.entity';
export declare class UsersController {
    private userService;
    constructor(userService: UsersService);
    create(body: User): Promise<User>;
    find(email: string): any;
    findAll(): any;
}
