export declare class TempUser {
    tempUserId: string;
    createdAt: number;
    massagesCount: number;
}
