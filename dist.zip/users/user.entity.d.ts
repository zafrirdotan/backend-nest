import * as mongoose from 'mongoose';
export declare const UserSchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    id?: number;
    name?: string;
    email?: string;
}, mongoose.Document<unknown, {}, {
    id?: number;
    name?: string;
    email?: string;
}> & {
    id?: number;
    name?: string;
    email?: string;
} & {
    _id: mongoose.Types.ObjectId;
}>;
export interface User {
    id?: number;
    name: string;
    email: string;
}
