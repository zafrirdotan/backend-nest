import { Response } from 'express';
import { ConversationService } from './conversation.service';
import { ChatCompletionRequestMessage } from 'openai';
import { Request } from 'express';
import { CompletionBody } from './dto/completion-body.dto';
import { AuthService } from 'src/auth/auth.service';
export declare class ConversationController {
    private readonly conversationService;
    private authService;
    constructor(conversationService: ConversationService, authService: AuthService);
    chatCompletion(completionMessage: ChatCompletionRequestMessage[]): Promise<{
        message: import("openai").ChatCompletionResponseMessage;
        summery: any;
    }>;
    chatCompletionStreaming(res: Response, completionBody: CompletionBody, req: Request): Promise<void>;
    getCompletion(res: Response, data: {
        prompt: string;
    }): Promise<void>;
}
