"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationController = void 0;
const common_1 = require("@nestjs/common");
const conversation_service_1 = require("./conversation.service");
const passport_1 = require("@nestjs/passport");
const auth_service_1 = require("../auth/auth.service");
let ConversationController = exports.ConversationController = class ConversationController {
    constructor(conversationService, authService) {
        this.conversationService = conversationService;
        this.authService = authService;
    }
    chatCompletion(completionMessage) {
        return this.conversationService.chatWithAI(completionMessage);
    }
    async chatCompletionStreaming(res, completionBody, req) {
        var _a, _b;
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Connection', 'keep-alive');
        if (((_a = req.user) === null || _a === void 0 ? void 0 : _a.hasOwnProperty('type')) && ((_b = req.user) === null || _b === void 0 ? void 0 : _b.type) === 'temp_user') {
            const tempUser = req.user;
            if ((tempUser === null || tempUser === void 0 ? void 0 : tempUser.type) === 'temp_user') {
                const newTempToken = await this.authService.refreshTempUserToken(tempUser);
                res.cookie('token', newTempToken, {
                    httpOnly: true,
                    expires: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7),
                });
            }
        }
        res.flushHeaders();
        const stream = (await this.conversationService.chatCompletionStreaming(completionBody.messages));
        stream.on('data', (data) => {
            var _a, _b;
            const lines = data.toString().split('\n').filter(line => line.trim() !== '');
            for (const line of lines) {
                const message = line.replace(/^data: /, '');
                if (message === '[DONE]') {
                    res.end();
                    return;
                }
                if (message) {
                    try {
                        const parsed = JSON.parse(message);
                        if ((parsed === null || parsed === void 0 ? void 0 : parsed.choices) && ((_b = (_a = parsed.choices[0]) === null || _a === void 0 ? void 0 : _a.delta) === null || _b === void 0 ? void 0 : _b.content)) {
                            res.write(parsed.choices[0].delta.content);
                        }
                    }
                    catch (e) {
                        console.log('error in streaming chat compilation:', e);
                        console.log('line:', line);
                        console.log('message:', message);
                    }
                }
            }
        });
        stream.on('end', () => {
            res.end();
        });
    }
    async getCompletion(res, data) {
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Connection', 'keep-alive');
        res.flushHeaders();
        const stream = (await this.conversationService.getCompletion(data.prompt));
        stream.on('data', (data) => {
            var _a;
            const lines = data.toString().split('\n').filter(line => line.trim() !== '');
            for (const line of lines) {
                const message = line.replace(/^data: /, '');
                if (message === '[DONE]') {
                    res.end();
                    return;
                }
                if (message) {
                    try {
                        const parsed = JSON.parse(message);
                        const choices = parsed === null || parsed === void 0 ? void 0 : parsed.choices;
                        if (choices && ((_a = choices[0]) === null || _a === void 0 ? void 0 : _a.text)) {
                            res.write(parsed.choices[0].text);
                        }
                    }
                    catch (e) {
                        console.log('error in streaming compilation:', e, 'message:', message);
                    }
                }
            }
        });
        stream.on('end', () => {
            res.end();
        });
    }
};
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", void 0)
], ConversationController.prototype, "chatCompletion", null);
__decorate([
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt-allow-3-first')),
    (0, common_1.Post)('streaming'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, Object]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "chatCompletionStreaming", null);
__decorate([
    (0, common_1.Post)('question-summery'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ConversationController.prototype, "getCompletion", null);
exports.ConversationController = ConversationController = __decorate([
    (0, common_1.Controller)('api/conversation'),
    __metadata("design:paramtypes", [conversation_service_1.ConversationService, auth_service_1.AuthService])
], ConversationController);
//# sourceMappingURL=conversation.controller.js.map