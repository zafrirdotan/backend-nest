"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationService = void 0;
const common_1 = require("@nestjs/common");
const openai_1 = require("openai");
const rxjs_1 = require("rxjs");
let ConversationService = exports.ConversationService = class ConversationService {
    constructor() {
        this.stream = new rxjs_1.Subject();
    }
    async chatWithAI(completionMessage) {
        const stattTime = Date.now();
        const responseMessage = await this.getChatCompletion(completionMessage);
        const response = { message: responseMessage, summery: undefined };
        if (completionMessage.length === 1) {
            response.summery = await this.getCompletion(completionMessage[0].content);
        }
        console.log('end time', Date.now() - stattTime);
        return response;
    }
    async getChatCompletion(completionMessage) {
        const completion = await this.getOpenAI().createChatCompletion({
            model: "gpt-3.5-turbo",
            messages: completionMessage,
            temperature: 0.9,
            max_tokens: 200,
            user: "user-1234",
        });
        return completion.data.choices[0].message;
    }
    async getCompletion(prompt) {
        const completion = await this.getOpenAI().createCompletion({
            model: "text-davinci-003",
            prompt: `summarize 6 words: ${prompt}`,
            max_tokens: 7,
            temperature: 0,
            stream: true,
        }, { responseType: 'stream' });
        return completion.data;
    }
    async chatCompletionStreaming(completionMessage) {
        const completion = await this.getOpenAI().createChatCompletion({
            model: "gpt-3.5-turbo-0613",
            messages: completionMessage,
            temperature: 0.9,
            stream: true,
        }, { responseType: 'stream' });
        return completion.data;
    }
    getOpenAI() {
        const configuration = new openai_1.Configuration({
            organization: "org-X0n7hfF6tJjf4a3wkduvdzGS",
            apiKey: process.env.OPENAI_API_KEY_YOSI,
        });
        return new openai_1.OpenAIApi(configuration);
    }
};
exports.ConversationService = ConversationService = __decorate([
    (0, common_1.Injectable)()
], ConversationService);
//# sourceMappingURL=conversation.service.js.map