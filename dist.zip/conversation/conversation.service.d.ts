/// <reference types="node" />
import { IncomingMessage } from 'http';
import { ChatCompletionRequestMessage, OpenAIApi } from "openai";
import { Subject } from 'rxjs';
export declare class ConversationService {
    stream: Subject<MessageEvent<any>>;
    chatWithAI(completionMessage: ChatCompletionRequestMessage[]): Promise<{
        message: import("openai").ChatCompletionResponseMessage;
        summery: any;
    }>;
    getChatCompletion(completionMessage: ChatCompletionRequestMessage[]): Promise<import("openai").ChatCompletionResponseMessage>;
    getCompletion(prompt: string): Promise<IncomingMessage>;
    chatCompletionStreaming(completionMessage: ChatCompletionRequestMessage[]): Promise<IncomingMessage>;
    getOpenAI(): OpenAIApi;
}
