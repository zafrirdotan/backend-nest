export declare class TempUser {
    type: 'temp_user' | 'user';
    messageCount?: number;
    firstCreatedAt?: Date;
}
