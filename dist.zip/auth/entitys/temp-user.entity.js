"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TempUser = void 0;
class TempUser {
}
exports.TempUser = TempUser;
//# sourceMappingURL=temp-user.entity.js.map