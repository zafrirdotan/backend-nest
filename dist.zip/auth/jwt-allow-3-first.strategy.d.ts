import { AuthService } from "./auth.service";
import { TempUser } from "./entitys/temp-user.entity";
declare const JwtAllow3FirstStrategy_base: new (...args: any[]) => any;
export declare class JwtAllow3FirstStrategy extends JwtAllow3FirstStrategy_base {
    private authService;
    constructor(authService: AuthService);
    validate(payload: any): Promise<import("../users/user.entity").User | TempUser>;
    private static extractJWT;
    private static extractTempUserJWT;
}
export {};
