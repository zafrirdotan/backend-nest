export declare class PasswordLessLoginDto {
    destination: string;
}
