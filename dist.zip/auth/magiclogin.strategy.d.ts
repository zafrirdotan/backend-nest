import Strategy from "passport-magic-login";
import { AuthService } from "./auth.service";
import { MailerService } from "src/mailer/mailer.service";
declare const MagicLoginStrategy_base: new (...args: any[]) => Strategy;
export declare class MagicLoginStrategy extends MagicLoginStrategy_base {
    private authService;
    private readonly mailerService;
    private readonly logger;
    constructor(authService: AuthService, mailerService: MailerService);
    validate(payload: {
        destination: string;
    }): Promise<import("../users/user.entity").User>;
}
export {};
