"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var JwtAllow3FirstStrategy_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtAllow3FirstStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_jwt_1 = require("passport-jwt");
const passport_1 = require("@nestjs/passport");
const auth_service_1 = require("./auth.service");
let JwtAllow3FirstStrategy = exports.JwtAllow3FirstStrategy = JwtAllow3FirstStrategy_1 = class JwtAllow3FirstStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy, 'jwt-allow-3-first') {
    constructor(authService) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromExtractors([
                JwtAllow3FirstStrategy_1.extractJWT,
                JwtAllow3FirstStrategy_1.extractTempUserJWT,
            ]),
            ignoreExpiration: false,
            secretOrKey: process.env.JWT_SECRET,
        });
        this.authService = authService;
    }
    async validate(payload) {
        if (payload.type === 'temp_user' && payload.messageCount < 3) {
            const temp_user = { messageCount: payload.messageCount, firstCreatedAt: payload.firstCreatedAt, type: payload.type };
            return temp_user;
        }
        else {
            const user = await this.authService.validateUser(payload.email);
            return user;
        }
    }
    static extractJWT(req) {
        var _a, _b, _c;
        if (((_c = (_b = (_a = req === null || req === void 0 ? void 0 : req.cookies) === null || _a === void 0 ? void 0 : _a.token) === null || _b === void 0 ? void 0 : _b.access_token) === null || _c === void 0 ? void 0 : _c.length) > 0) {
            return req.cookies.token.access_token;
        }
        return null;
    }
    static extractTempUserJWT(req) {
        var _a, _b, _c;
        if (((_c = (_b = (_a = req === null || req === void 0 ? void 0 : req.cookies) === null || _a === void 0 ? void 0 : _a.token) === null || _b === void 0 ? void 0 : _b.temp_user_access_token) === null || _c === void 0 ? void 0 : _c.length) > 0) {
            return req.cookies.token.temp_user_access_token;
        }
        return null;
    }
};
exports.JwtAllow3FirstStrategy = JwtAllow3FirstStrategy = JwtAllow3FirstStrategy_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], JwtAllow3FirstStrategy);
//# sourceMappingURL=jwt-allow-3-first.strategy.js.map