"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
const magiclogin_strategy_1 = require("./magiclogin.strategy");
const passwoedless_login_dto_1 = require("./passwoedless-login.dto");
const passport_1 = require("@nestjs/passport");
const magicSignup_strategy_1 = require("./magicSignup.strategy");
let AuthController = exports.AuthController = class AuthController {
    constructor(authService, magicLoginStrategy, magicSignupStrategy) {
        this.authService = authService;
        this.magicLoginStrategy = magicLoginStrategy;
        this.magicSignupStrategy = magicSignupStrategy;
    }
    login(req, res, body) {
        this.authService.validateUser(body.destination);
        return this.magicLoginStrategy.send(req, res);
    }
    loginCallback(req, res) {
        console.log('callback');
        const token = this.authService.generateTokens(req.user);
        res.cookie('token', token, {
            httpOnly: true,
        });
        res.send(req.user);
    }
    async isLoggedIn(req) {
        var _a, _b, _c;
        if ((_c = (_b = (_a = req === null || req === void 0 ? void 0 : req.cookies) === null || _a === void 0 ? void 0 : _a.token) === null || _b === void 0 ? void 0 : _b.access_token) === null || _c === void 0 ? void 0 : _c.length) {
            const user = await this.authService.getUserFromToken(req.cookies.token.access_token);
            if (user) {
                return { isLoggedIn: true, user };
            }
            else {
                return { isLoggedIn: false };
            }
        }
    }
    getTemp(res, req) {
        var _a, _b, _c, _d, _e, _f;
        if (((_c = (_b = (_a = req === null || req === void 0 ? void 0 : req.cookies) === null || _a === void 0 ? void 0 : _a.token) === null || _b === void 0 ? void 0 : _b.temp_user_access_token) === null || _c === void 0 ? void 0 : _c.length) || ((_f = (_e = (_d = req === null || req === void 0 ? void 0 : req.cookies) === null || _d === void 0 ? void 0 : _d.token) === null || _e === void 0 ? void 0 : _e.access_token) === null || _f === void 0 ? void 0 : _f.length)) {
            res.send({ status: 'exists' });
            return;
        }
        const temp_token = this.authService.generateTempUserToken();
        res.cookie('token', temp_token, {
            httpOnly: true,
        });
        res.send({ status: 'created' });
    }
    logout(res) {
        res.clearCookie('token');
        res.send({ status: 'ok' });
    }
    signup(req, res, body) {
        const user = this.authService.validateUser(body.destination);
        if (user) {
            throw new common_1.HttpException('User already exists', 400);
        }
        else {
            return this.magicSignupStrategy.send(req, res);
        }
    }
    async signupCallback(req, res) {
        const user = await this.authService.createNewUser(req.body.fullName, req.user.email);
        const token = this.authService.generateTokens(user);
        res.cookie('token', token, {
            httpOnly: true,
        });
        res.send(user);
    }
};
__decorate([
    (0, common_1.Post)('login'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Body)(new common_1.ValidationPipe())),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, passwoedless_login_dto_1.PasswordLessLoginDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "login", null);
__decorate([
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('magiclogin')),
    (0, common_1.Get)('login/callback'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "loginCallback", null);
__decorate([
    (0, common_1.Get)('is-logged-in'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "isLoggedIn", null);
__decorate([
    (0, common_1.Get)('temp-user'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "getTemp", null);
__decorate([
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('jwt')),
    (0, common_1.Get)('logout'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "logout", null);
__decorate([
    (0, common_1.Post)('signup'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __param(2, (0, common_1.Body)(new common_1.ValidationPipe())),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object, passwoedless_login_dto_1.PasswordLessLoginDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "signup", null);
__decorate([
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('magicSignup')),
    (0, common_1.Post)('signup/callback'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "signupCallback", null);
exports.AuthController = AuthController = __decorate([
    (0, common_1.Controller)('api/auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService, magiclogin_strategy_1.MagicLoginStrategy, magicSignup_strategy_1.MagicSignupStrategy])
], AuthController);
//# sourceMappingURL=auth.controller.js.map