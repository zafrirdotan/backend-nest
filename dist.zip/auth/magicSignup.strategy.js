"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MagicSignupStrategy_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MagicSignupStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_magic_login_1 = require("passport-magic-login");
const auth_service_1 = require("./auth.service");
const mailer_service_1 = require("../mailer/mailer.service");
let MagicSignupStrategy = exports.MagicSignupStrategy = MagicSignupStrategy_1 = class MagicSignupStrategy extends (0, passport_1.PassportStrategy)(passport_magic_login_1.default, 'magicSignup') {
    constructor(authService, mailerService) {
        super({
            secret: process.env.MAGICLINK_SECRET,
            jwtOptions: {
                expiresIn: "1d",
            },
            callbackUrl: process.env.MAGICLINK_SIGNUP_CALLBACK_URL,
            confirmationUrl: process.env.MAGICLINK_CONFIRMATION_URL,
            sendMagicLink: async (destination, href) => {
                this.mailerService.sendUserSignupLink({ email: destination }, href);
            },
            verify: async (payload, callback) => {
                callback(null, this.validate(payload));
            }
        });
        this.authService = authService;
        this.mailerService = mailerService;
        this.logger = new common_1.Logger(MagicSignupStrategy_1.name);
    }
    async validate(payload) {
        if (payload.destination) {
            const user = await this.authService.findUserByEmail(payload.destination);
            if (!user) {
                return { email: payload.destination };
            }
            else {
                throw new common_1.HttpException('User already exists', 400);
            }
        }
        else {
            throw new common_1.UnauthorizedException;
        }
    }
};
exports.MagicSignupStrategy = MagicSignupStrategy = MagicSignupStrategy_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [auth_service_1.AuthService, mailer_service_1.MailerService])
], MagicSignupStrategy);
//# sourceMappingURL=magicSignup.strategy.js.map