import Strategy from "passport-magic-login";
import { AuthService } from "./auth.service";
import { MailerService } from "src/mailer/mailer.service";
declare const MagicSignupStrategy_base: new (...args: any[]) => Strategy;
export declare class MagicSignupStrategy extends MagicSignupStrategy_base {
    private authService;
    private readonly mailerService;
    private readonly logger;
    constructor(authService: AuthService, mailerService: MailerService);
    validate(payload: {
        destination: string;
    }): Promise<{
        email: string;
    }>;
}
export {};
