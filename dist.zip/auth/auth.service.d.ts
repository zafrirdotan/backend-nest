import { JwtService } from '@nestjs/jwt';
import { User } from 'src/users/user.entity';
import { UsersService } from 'src/users/users.service';
import { TempUser } from './entitys/temp-user.entity';
export declare class AuthService {
    private usersService;
    private jwtService;
    constructor(usersService: UsersService, jwtService: JwtService);
    validateUser(email: string): Promise<User | undefined>;
    findUserByEmail(email: string): Promise<User | undefined>;
    generateTokens(user: User): {
        access_token: string;
    };
    generateTokenFromMail(email: string): string;
    generateTempUserToken(): {
        temp_user_access_token: string;
    };
    refreshTempUserToken(tempUser: TempUser): {
        temp_user_access_token: string;
    };
    getUserFromToken(token: string): Promise<User | undefined>;
    createNewUser(name: string, email: string): Promise<User>;
}
