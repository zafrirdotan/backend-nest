import { Response, Request } from 'express';
import { AuthService } from './auth.service';
import { MagicLoginStrategy } from './magiclogin.strategy';
import { PasswordLessLoginDto } from './passwoedless-login.dto';
import { User } from 'src/users/user.entity';
import { MagicSignupStrategy } from './magicSignup.strategy';
export declare class AuthController {
    private readonly authService;
    private magicLoginStrategy;
    private magicSignupStrategy;
    constructor(authService: AuthService, magicLoginStrategy: MagicLoginStrategy, magicSignupStrategy: MagicSignupStrategy);
    login(req: any, res: any, body: PasswordLessLoginDto): void;
    loginCallback(req: any, res: Response): void;
    isLoggedIn(req: Request): Promise<{
        isLoggedIn: boolean;
        user: User;
    } | {
        isLoggedIn: boolean;
        user?: undefined;
    }>;
    getTemp(res: any, req: Request): void;
    logout(res: any): void;
    signup(req: any, res: any, body: PasswordLessLoginDto): void;
    signupCallback(req: any, res: Response): Promise<void>;
}
