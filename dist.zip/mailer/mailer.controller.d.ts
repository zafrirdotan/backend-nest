import { MailerService } from './mailer.service';
export declare class MailerController {
    private readonly mailerService;
    constructor(mailerService: MailerService);
    sendMail(): any;
    sendTemplate(): any;
}
