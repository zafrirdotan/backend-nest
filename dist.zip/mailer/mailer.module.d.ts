export declare class MailerModule {
}
