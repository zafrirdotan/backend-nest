"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MailerService = void 0;
const common_1 = require("@nestjs/common");
const mailer_1 = require("@nestjs-modules/mailer");
const googleapis_1 = require("googleapis");
let MailerService = exports.MailerService = class MailerService {
    constructor(mailerService) {
        this.mailerService = mailerService;
    }
    async sendUserLoginLink(user, href) {
        await this.setTransport();
        await this.mailerService.sendMail({
            transporterName: 'gmail',
            to: user.email,
            from: 'zafrir.dotan@gmail.com',
            subject: 'Welcome to our site',
            template: './welcome',
            context: {
                href: href,
                username: user.username,
            },
        });
    }
    async sendUserSignupLink(user, href) {
        await this.setTransport();
        console.log('sendUserConfirmation', user, href);
        await this.mailerService.sendMail({
            transporterName: 'gmail',
            to: user.email,
            from: 'zafrir.dotan@gmail.com',
            subject: 'Welcome to our site',
            template: './signup',
            context: {
                href: href,
                username: user.username,
            },
        });
    }
    async setTransport() {
        const OAuth2 = googleapis_1.google.auth.OAuth2;
        const oauth2Client = new OAuth2(process.env.EMAIL_CLIENT_ID, process.env.EMAIL_CLIENT_SECRET, process.env.REDIRECT_URI);
        oauth2Client.setCredentials({
            refresh_token: process.env.REFRESH_TOKEN,
        });
        const accessToken = await new Promise((resolve, reject) => {
            oauth2Client.getAccessToken((err, token) => {
                if (err) {
                    console.log('Failed to create access token :', err);
                    reject('Failed to create access token');
                }
                resolve(token);
            });
        });
        const config = {
            service: 'gmail',
            auth: {
                type: 'OAuth2',
                user: 'zafrir.dotan@gmail.com',
                clientId: process.env.EMAIL_CLIENT_ID,
                clientSecret: process.env.EMAIL_CLIENT_SECRET,
                accessToken,
            },
        };
        this.mailerService.addTransporter('gmail', config);
    }
};
exports.MailerService = MailerService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [mailer_1.MailerService])
], MailerService);
//# sourceMappingURL=mailer.service.js.map