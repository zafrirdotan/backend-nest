import { MailerService as NestMailerService } from '@nestjs-modules/mailer';
export declare class MailerService {
    private readonly mailerService;
    constructor(mailerService: NestMailerService);
    sendUserLoginLink(user: {
        email: any;
        username?: string;
    }, href: any): Promise<void>;
    sendUserSignupLink(user: any, href: string): Promise<void>;
    private setTransport;
}
